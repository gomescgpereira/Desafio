﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gomes.Shared
{
    public static class Settings
    {
        public static string ConnectionString = @"Server=.\sqlexpress;Database=baltastore;User ID=baltastore;Password=sqlexpress;";
        
        public static string Database  = "delivery";
    }

}
