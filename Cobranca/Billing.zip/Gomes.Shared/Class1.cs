﻿using System;

namespace Gomes.Shared
{
    public class Class1
    {
    }
}
