﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gomes.Shared
{
    public static class Settings
    {
        public static string ConnectionString = "mongodb+srv://admin:kt-341gb@cluster0-pbq16.mongodb.net/test?retryWrites=true&w=majority";
        public static string Database  = "delivery";
    }

}
