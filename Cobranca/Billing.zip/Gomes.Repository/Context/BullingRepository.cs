using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MongoDB.Driver;
//using Microsoft.Extensions.Options;
using MongoDB.Bson;
using Gomes.Shared;
using Gomes.Domain.Context.Repository;
using Gomes.Domain.Context.Entity;

namespace Gomes.Reposirory.Context 
{
    public class BullingRepository : IRepositoryBulling
    {
        private readonly IMongoCollection<Bulling> _categories;
        

        public BullingRepository()
        {
            var client = new MongoClient(Settings.ConnectionString);
            var database = client.GetDatabase(Settings.Database);
            _categories = database.GetCollection<Bulling>("categories");

        }

        public Task Add(Bulling model)
        {
            throw new NotImplementedException();
        }

        public async Task InsertUser(Bulling model)
        {
            await _categories.InsertOneAsync(model);
        }

        public async Task<IEnumerable<Bulling>> GetAll()
        {
            return await _categories.Find(new BsonDocument()).ToListAsync();
        }

        public async Task<Bulling> GetMonth(int mes)
        {
            string ano = "09";
            //x => x.Title.Contains("s");
            //var filter = Builders<Bulling>.Filter.Eq(x => (x.Vencimento.AsString).Contains(ano));
            //var filter = Builders<Bulling>.Filter.Eq(} );
            // var filterBuilder = Builders<Bulling>.Filter;
            // var start = new DateTime(2019, 09, 01);
            // var end = new DateTime(2019, 09, 30);
            // var filter = filterBuilder.Gte(x => x.Vencimento, new BsonDateTime(start)) & filterBuilder.Lte(x => x.Vencimento, new BsonDateTime(end));
            return await _categories.Find({ "$where": "this.Vencimento.getMonth() === 9"}).FirstOrDefaultAsync();
           // return await _categories.Find(filter).FirstOrDefaultAsync();
        }

         public Task<Bulling> Get(string name)
         {
             throw new NotImplementedException();
         }


        public Task<Bulling> Remove(string name)
        {
            throw new NotImplementedException();
        }

        public Task UpDate(Bulling model)
        {
            throw new NotImplementedException();
        }

        Task<IEnumerable<Bulling>> IRepositoryBulling.GetAll()
        {
            throw new NotImplementedException();
        }

        
    }


}