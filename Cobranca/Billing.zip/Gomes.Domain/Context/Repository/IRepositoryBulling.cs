using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Gomes.Domain.Context.Entity;
  

namespace Gomes.Domain.Context.Repository
{
  public interface IRepositoryBulling 
  
  {
        Task<IEnumerable<Bulling>> GetAll();
        Task<Bulling> Get(string name);
        Task Add(Bulling model);

        Task UpDate(Bulling  model);
        Task<Bulling> Remove(string name);

  }
}