﻿using System;

namespace Gomes.Domain
{
    public class Class1
    {
    }
}
